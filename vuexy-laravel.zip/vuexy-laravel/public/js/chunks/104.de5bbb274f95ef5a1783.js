(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[104],{

/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/ui/typography/Typography.vue?vue&type=script&lang=js&":
/*!**********************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/ui/typography/Typography.vue?vue&type=script&lang=js& ***!
  \**********************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _TypographyDefault_vue__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./TypographyDefault.vue */ "./resources/js/src/views/ui/typography/TypographyDefault.vue");
/* harmony import */ var _TypographyDisplay_vue__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./TypographyDisplay.vue */ "./resources/js/src/views/ui/typography/TypographyDisplay.vue");
/* harmony import */ var _TypographyBlockquotes_vue__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./TypographyBlockquotes.vue */ "./resources/js/src/views/ui/typography/TypographyBlockquotes.vue");
/* harmony import */ var _TypographyList_vue__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./TypographyList.vue */ "./resources/js/src/views/ui/typography/TypographyList.vue");
/* harmony import */ var _TypographyDescription_vue__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./TypographyDescription.vue */ "./resources/js/src/views/ui/typography/TypographyDescription.vue");





/* harmony default export */ __webpack_exports__["default"] = ({
  components: {
    TypographyDefault: _TypographyDefault_vue__WEBPACK_IMPORTED_MODULE_0__["default"],
    TypographyDisplay: _TypographyDisplay_vue__WEBPACK_IMPORTED_MODULE_1__["default"],
    TypographyBlockquotes: _TypographyBlockquotes_vue__WEBPACK_IMPORTED_MODULE_2__["default"],
    TypographyList: _TypographyList_vue__WEBPACK_IMPORTED_MODULE_3__["default"],
    TypographyDescription: _TypographyDescription_vue__WEBPACK_IMPORTED_MODULE_4__["default"]
  }
});

/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/ui/typography/TypographyBlockquotes.vue?vue&type=script&lang=js&":
/*!*********************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/ui/typography/TypographyBlockquotes.vue?vue&type=script&lang=js& ***!
  \*********************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var bootstrap_vue__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! bootstrap-vue */ "./node_modules/bootstrap-vue/esm/index.js");

/* harmony default export */ __webpack_exports__["default"] = ({
  components: {
    BRow: bootstrap_vue__WEBPACK_IMPORTED_MODULE_0__["BRow"],
    BCol: bootstrap_vue__WEBPACK_IMPORTED_MODULE_0__["BCol"],
    BCard: bootstrap_vue__WEBPACK_IMPORTED_MODULE_0__["BCard"],
    BImg: bootstrap_vue__WEBPACK_IMPORTED_MODULE_0__["BImg"],
    BCardHeader: bootstrap_vue__WEBPACK_IMPORTED_MODULE_0__["BCardHeader"],
    BCardBody: bootstrap_vue__WEBPACK_IMPORTED_MODULE_0__["BCardBody"],
    BCardText: bootstrap_vue__WEBPACK_IMPORTED_MODULE_0__["BCardText"],
    BCardTitle: bootstrap_vue__WEBPACK_IMPORTED_MODULE_0__["BCardTitle"],
    BMedia: bootstrap_vue__WEBPACK_IMPORTED_MODULE_0__["BMedia"],
    BMediaAside: bootstrap_vue__WEBPACK_IMPORTED_MODULE_0__["BMediaAside"],
    BMediaBody: bootstrap_vue__WEBPACK_IMPORTED_MODULE_0__["BMediaBody"]
  }
});

/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/ui/typography/TypographyDefault.vue?vue&type=script&lang=js&":
/*!*****************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/ui/typography/TypographyDefault.vue?vue&type=script&lang=js& ***!
  \*****************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var bootstrap_vue__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! bootstrap-vue */ "./node_modules/bootstrap-vue/esm/index.js");

/* harmony default export */ __webpack_exports__["default"] = ({
  components: {
    BRow: bootstrap_vue__WEBPACK_IMPORTED_MODULE_0__["BRow"],
    BCol: bootstrap_vue__WEBPACK_IMPORTED_MODULE_0__["BCol"],
    BCard: bootstrap_vue__WEBPACK_IMPORTED_MODULE_0__["BCard"],
    BTableSimple: bootstrap_vue__WEBPACK_IMPORTED_MODULE_0__["BTableSimple"],
    BCardHeader: bootstrap_vue__WEBPACK_IMPORTED_MODULE_0__["BCardHeader"],
    BCardBody: bootstrap_vue__WEBPACK_IMPORTED_MODULE_0__["BCardBody"],
    BCardTitle: bootstrap_vue__WEBPACK_IMPORTED_MODULE_0__["BCardTitle"],
    BCardText: bootstrap_vue__WEBPACK_IMPORTED_MODULE_0__["BCardText"],
    BThead: bootstrap_vue__WEBPACK_IMPORTED_MODULE_0__["BThead"],
    BTr: bootstrap_vue__WEBPACK_IMPORTED_MODULE_0__["BTr"],
    BTh: bootstrap_vue__WEBPACK_IMPORTED_MODULE_0__["BTh"],
    BTbody: bootstrap_vue__WEBPACK_IMPORTED_MODULE_0__["BTbody"],
    BTd: bootstrap_vue__WEBPACK_IMPORTED_MODULE_0__["BTd"]
  }
});

/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/ui/typography/TypographyDescription.vue?vue&type=script&lang=js&":
/*!*********************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/ui/typography/TypographyDescription.vue?vue&type=script&lang=js& ***!
  \*********************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var bootstrap_vue__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! bootstrap-vue */ "./node_modules/bootstrap-vue/esm/index.js");

/* harmony default export */ __webpack_exports__["default"] = ({
  components: {
    BRow: bootstrap_vue__WEBPACK_IMPORTED_MODULE_0__["BRow"],
    BCol: bootstrap_vue__WEBPACK_IMPORTED_MODULE_0__["BCol"],
    BCard: bootstrap_vue__WEBPACK_IMPORTED_MODULE_0__["BCard"],
    BCardTitle: bootstrap_vue__WEBPACK_IMPORTED_MODULE_0__["BCardTitle"],
    BCardText: bootstrap_vue__WEBPACK_IMPORTED_MODULE_0__["BCardText"],
    BCardHeader: bootstrap_vue__WEBPACK_IMPORTED_MODULE_0__["BCardHeader"],
    BCardBody: bootstrap_vue__WEBPACK_IMPORTED_MODULE_0__["BCardBody"]
  }
});

/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/ui/typography/TypographyDisplay.vue?vue&type=script&lang=js&":
/*!*****************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/ui/typography/TypographyDisplay.vue?vue&type=script&lang=js& ***!
  \*****************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var bootstrap_vue__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! bootstrap-vue */ "./node_modules/bootstrap-vue/esm/index.js");

/* harmony default export */ __webpack_exports__["default"] = ({
  components: {
    BCard: bootstrap_vue__WEBPACK_IMPORTED_MODULE_0__["BCard"],
    BCardBody: bootstrap_vue__WEBPACK_IMPORTED_MODULE_0__["BCardBody"],
    BCardText: bootstrap_vue__WEBPACK_IMPORTED_MODULE_0__["BCardText"],
    BCardTitle: bootstrap_vue__WEBPACK_IMPORTED_MODULE_0__["BCardTitle"],
    BTableSimple: bootstrap_vue__WEBPACK_IMPORTED_MODULE_0__["BTableSimple"],
    BTr: bootstrap_vue__WEBPACK_IMPORTED_MODULE_0__["BTr"],
    BTbody: bootstrap_vue__WEBPACK_IMPORTED_MODULE_0__["BTbody"],
    BTd: bootstrap_vue__WEBPACK_IMPORTED_MODULE_0__["BTd"]
  }
});

/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/ui/typography/TypographyList.vue?vue&type=script&lang=js&":
/*!**************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/ui/typography/TypographyList.vue?vue&type=script&lang=js& ***!
  \**************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var bootstrap_vue__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! bootstrap-vue */ "./node_modules/bootstrap-vue/esm/index.js");

/* harmony default export */ __webpack_exports__["default"] = ({
  components: {
    BRow: bootstrap_vue__WEBPACK_IMPORTED_MODULE_0__["BRow"],
    BCol: bootstrap_vue__WEBPACK_IMPORTED_MODULE_0__["BCol"],
    BCard: bootstrap_vue__WEBPACK_IMPORTED_MODULE_0__["BCard"],
    BCardText: bootstrap_vue__WEBPACK_IMPORTED_MODULE_0__["BCardText"],
    BCardTitle: bootstrap_vue__WEBPACK_IMPORTED_MODULE_0__["BCardTitle"]
  }
});

/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/ui/typography/Typography.vue?vue&type=template&id=ff57b404&":
/*!********************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/ui/typography/Typography.vue?vue&type=template&id=ff57b404& ***!
  \********************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function render() {
  var _vm = this,
      _c = _vm._self._c;

  return _c("div", [_c("typography-default"), _vm._v(" "), _c("typography-display"), _vm._v(" "), _c("typography-blockquotes"), _vm._v(" "), _c("typography-list"), _vm._v(" "), _c("typography-description")], 1);
};

var staticRenderFns = [];
render._withStripped = true;


/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/ui/typography/TypographyBlockquotes.vue?vue&type=template&id=275c3196&":
/*!*******************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/ui/typography/TypographyBlockquotes.vue?vue&type=template&id=275c3196& ***!
  \*******************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function render() {
  var _vm = this,
      _c = _vm._self._c;

  return _c("section", {
    attrs: {
      id: "blockquotes"
    }
  }, [_c("b-row", {
    staticClass: "match-height"
  }, [_c("b-col", {
    attrs: {
      cols: "12"
    }
  }, [_c("div", {
    staticClass: "group-area mt-1"
  }, [_c("h4", [_vm._v("Blockquotes")]), _vm._v(" "), _c("p", [_vm._v("\n          For quoting blocks of content from another source within your document. Wrap\n          "), _c("code", {
    staticClass: "highlighter-rouge"
  }, [_vm._v('<blockquote class="blockquote">')]), _vm._v(" around any\n          "), _c("abbr", {
    attrs: {
      title: "HyperText Markup Language"
    }
  }, [_vm._v("HTML")]), _vm._v(" as the quote.\n        ")]), _vm._v(" "), _c("hr")])]), _vm._v(" "), _c("b-col", {
    attrs: {
      md: "6"
    }
  }, [_c("b-card", {
    attrs: {
      "no-body": ""
    }
  }, [_c("b-card-header", [_c("b-card-title", [_vm._v("\n            Blockquotes "), _c("small", {
    staticClass: "text-muted"
  }, [_vm._v("Default")])])], 1), _vm._v(" "), _c("b-card-body", [_c("b-card-text", [_vm._v("\n            Left aligned basic blockquotes. Use text utilities classes like "), _c("code", [_vm._v(".text-center / .text-right")]), _vm._v(" as\n            needed to change the alignment of your blockquote.\n          ")]), _vm._v(" "), _c("blockquote", {
    staticClass: "blockquote"
  }, [_c("p", {
    staticClass: "mb-0"
  }, [_vm._v("\n              Design is not just what it looks like and feels like. Design is how it works.\n            ")])])], 1)], 1)], 1), _vm._v(" "), _c("b-col", {
    attrs: {
      md: "6"
    }
  }, [_c("b-card", {
    attrs: {
      "no-body": ""
    }
  }, [_c("b-card-header", [_c("b-card-title", [_vm._v("\n            Naming a source "), _c("small", {
    staticClass: "text-muted"
  }, [_vm._v("Default")])])], 1), _vm._v(" "), _c("b-card-body", [_c("b-card-text", [_vm._v("\n            Add a "), _c("code", {
    staticClass: "highlighter-rouge"
  }, [_vm._v('<footer class="blockquote-footer">')]), _vm._v(" for identifying the\n            source. Wrap the name of the source work in "), _c("code", {
    staticClass: "highlighter-rouge"
  }, [_vm._v("<cite>")]), _vm._v(".\n          ")]), _vm._v(" "), _c("blockquote", {
    staticClass: "blockquote"
  }, [_c("p", {
    staticClass: "mb-0"
  }, [_vm._v("\n              Being the richest man in the cemetery doesn't matter to me. Going to bed at night saying we've done\n              something wonderful, that's what matters to me.\n            ")]), _vm._v(" "), _c("footer", {
    staticClass: "blockquote-footer"
  }, [_vm._v("\n              Steve Jobs\n              "), _c("cite", {
    attrs: {
      title: "Source Title"
    }
  }, [_vm._v("Entrepreneur")])])])], 1)], 1)], 1), _vm._v(" "), _c("b-col", {
    attrs: {
      md: "6"
    }
  }, [_c("b-card", [_c("b-card-title", [_vm._v("\n          Blockquotes styling "), _c("small", {
    staticClass: "text-muted"
  }, [_vm._v("Default")])]), _vm._v(" "), _c("b-card-text", [_vm._v("\n          Add a "), _c("code", {
    staticClass: "highlighter-rouge"
  }, [_vm._v(".border-{left/right}-{color} .border-{left/right}-3")]), _vm._v(" helper\n          classes, where color can be any color from Vuexy Admin color palette.\n        ")]), _vm._v(" "), _c("blockquote", {
    staticClass: "blockquote pl-1 border-left-primary border-left-3"
  }, [_c("p", {
    staticClass: "mb-0"
  }, [_vm._v("\n            Sometimes when you innovate, you make mistakes. It is best to admit them quickly, and get on with improving\n            your other innovations.\n          ")]), _vm._v(" "), _c("footer", {
    staticClass: "blockquote-footer"
  }, [_vm._v("\n            Steve Jobs\n            "), _c("cite", {
    attrs: {
      title: "Source Title"
    }
  }, [_vm._v("Entrepreneur")])])]), _vm._v(" "), _c("blockquote", {
    staticClass: "blockquote pr-1 mt-2 text-right border-right-primary border-right-3"
  }, [_c("p", {
    staticClass: "mb-0"
  }, [_vm._v("\n            Sometimes when you innovate, you make mistakes. It is best to admit them quickly, and get on with improving\n            your other innovations.\n          ")]), _vm._v(" "), _c("footer", {
    staticClass: "blockquote-footer"
  }, [_vm._v("\n            Steve Jobs\n            "), _c("cite", {
    attrs: {
      title: "Source Title"
    }
  }, [_vm._v("Entrepreneur")])])])], 1)], 1), _vm._v(" "), _c("b-col", {
    attrs: {
      md: "6"
    }
  }, [_c("b-card", [_c("b-card-title", [_vm._v("Blockquotes with avatar Default")]), _vm._v(" "), _c("b-card-text", [_vm._v("\n          Blockquotes with avatar. it use Media Object. You can customize image type, border alignment & style.\n        ")]), _vm._v(" "), _c("blockquote", {
    staticClass: "blockquote pl-1 border-left-primary border-left-3"
  }, [_c("b-media", {
    attrs: {
      "no-body": ""
    }
  }, [_c("b-media-aside", {
    staticClass: "mr-1"
  }, [_c("b-img", {
    attrs: {
      src: __webpack_require__(/*! @/assets/images/portrait/small/avatar-s-5.jpg */ "./resources/js/src/assets/images/portrait/small/avatar-s-5.jpg"),
      alt: "Generic placeholder image",
      height: "64",
      width: "64"
    }
  })], 1), _vm._v(" "), _c("b-media-body", [_vm._v("\n              Sometimes life is going to hit you in the head with a brick. Don't lose faith.\n            ")])], 1), _vm._v(" "), _c("footer", {
    staticClass: "blockquote-footer text-right"
  }, [_vm._v("\n            Steve Jobs\n            "), _c("cite", {
    attrs: {
      title: "Source Title"
    }
  }, [_vm._v("Entrepreneur")])])], 1), _vm._v(" "), _c("b-card-text", {
    staticClass: "mt-2"
  }, [_vm._v("\n          Blockquotes with avatar rounded image example\n        ")]), _vm._v(" "), _c("blockquote", {
    staticClass: "blockquote mt-1"
  }, [_c("b-media", {
    attrs: {
      "no-body": ""
    }
  }, [_c("b-media-aside", {
    staticClass: "mr-1"
  }, [_c("b-img", {
    attrs: {
      rounded: "circle",
      src: __webpack_require__(/*! @/assets/images/portrait/small/avatar-s-3.jpg */ "./resources/js/src/assets/images/portrait/small/avatar-s-3.jpg"),
      alt: "Generic placeholder image",
      height: "64",
      width: "64"
    }
  })], 1), _vm._v(" "), _c("b-media-body", [_vm._v("\n              Sometimes life is going to hit you in the head with a brick. Don't lose faith.\n            ")])], 1), _vm._v(" "), _c("footer", {
    staticClass: "blockquote-footer text-right"
  }, [_vm._v("\n            Steve Jobs\n            "), _c("cite", {
    attrs: {
      title: "Source Title"
    }
  }, [_vm._v("Entrepreneur")])])], 1)], 1)], 1)], 1)], 1);
};

var staticRenderFns = [];
render._withStripped = true;


/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/ui/typography/TypographyDefault.vue?vue&type=template&id=05503613&":
/*!***************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/ui/typography/TypographyDefault.vue?vue&type=template&id=05503613& ***!
  \***************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function render() {
  var _vm = this,
      _c = _vm._self._c;

  return _c("b-row", {
    staticClass: "match-height"
  }, [_c("b-col", {
    attrs: {
      md: "6"
    }
  }, [_c("b-card", {
    attrs: {
      "no-body": ""
    }
  }, [_c("b-card-header", [_c("b-card-title", [_vm._v("HTML headings "), _c("small", {
    staticClass: "text-muted"
  }, [_vm._v("Default")])])], 1), _vm._v(" "), _c("b-card-body", {
    staticClass: "pb-1"
  }, [_c("b-card-text", [_vm._v("\n          All HTML headings, "), _c("code", [_vm._v("<h1>")]), _vm._v(" through "), _c("code", [_vm._v("<h6>")]), _vm._v(", are available.\n          "), _c("code", [_vm._v(".h1")]), _vm._v(" through "), _c("code", [_vm._v(".h6")]), _vm._v(" classes are also available, for when you want to match the font\n          styling of a heading.\n        ")])], 1), _vm._v(" "), _c("b-table-simple", {
    attrs: {
      borderless: ""
    }
  }, [_c("b-thead", {
    attrs: {
      "head-variant": "danger"
    }
  }, [_c("b-tr", [_c("b-th", [_vm._v("PREVIEW")]), _vm._v(" "), _c("b-th", {
    staticClass: "text-right"
  }, [_vm._v("\n              FONT SIZE\n            ")])], 1)], 1), _vm._v(" "), _c("b-tbody", [_c("b-tr", [_c("b-td", [_c("h1", [_vm._v("H1 Heading")])]), _vm._v(" "), _c("b-td", {
    staticClass: "text-right"
  }, [_vm._v("\n              2rem\n            ")])], 1), _vm._v(" "), _c("b-tr", [_c("b-td", [_c("h2", [_vm._v("H2 Heading")])]), _vm._v(" "), _c("b-td", {
    staticClass: "text-right"
  }, [_vm._v("\n              1.714rem\n            ")])], 1), _vm._v(" "), _c("b-tr", [_c("b-td", [_c("h3", [_vm._v("H3 Heading")])]), _vm._v(" "), _c("b-td", {
    staticClass: "text-right"
  }, [_vm._v("\n              1.5rem\n            ")])], 1), _vm._v(" "), _c("b-tr", [_c("b-td", [_c("h4", [_vm._v("H4 Heading")])]), _vm._v(" "), _c("b-td", {
    staticClass: "text-right"
  }, [_vm._v("\n              1.286rem\n            ")])], 1), _vm._v(" "), _c("b-tr", [_c("b-td", [_c("h5", [_vm._v("H5 Heading")])]), _vm._v(" "), _c("b-td", {
    staticClass: "text-right"
  }, [_vm._v("\n              1.07rem\n            ")])], 1), _vm._v(" "), _c("b-tr", [_c("b-td", [_c("h6", [_vm._v("H6 Heading")])]), _vm._v(" "), _c("b-td", {
    staticClass: "text-right"
  }, [_vm._v("\n              1rem\n            ")])], 1)], 1)], 1)], 1)], 1), _vm._v(" "), _c("b-col", {
    attrs: {
      md: "6"
    }
  }, [_c("b-card", {
    attrs: {
      "no-body": ""
    }
  }, [_c("b-card-header", [_c("b-card-title", [_vm._v("Light / Bold Headings")])], 1), _vm._v(" "), _c("b-card-body", {
    staticClass: "pb-1"
  }, [_c("b-card-text", [_vm._v("\n          All HTML headings are available with light and bold font-weight. Use "), _c("code", [_vm._v(".font-weight-normal")]), _vm._v(" for\n          light heading and "), _c("code", [_vm._v(".font-weight-bolder")]), _vm._v(" for bold headings along with heading tags or classes.\n        ")])], 1), _vm._v(" "), _c("b-table-simple", {
    attrs: {
      borderless: ""
    }
  }, [_c("b-thead", {
    attrs: {
      "head-variant": "danger"
    }
  }, [_c("b-tr", [_c("b-th", [_vm._v("LIGHT HEADINGS")]), _vm._v(" "), _c("b-th", {
    staticClass: "text-right"
  }, [_vm._v("\n              BOLD HEADINGS\n            ")])], 1)], 1), _vm._v(" "), _c("b-tbody", [_c("b-tr", [_c("b-td", [_c("h1", {
    staticClass: "font-weight-normal"
  }, [_vm._v("\n                Heading 1\n              ")])]), _vm._v(" "), _c("b-td", {
    staticClass: "text-right"
  }, [_c("h1", {
    staticClass: "font-weight-bolder"
  }, [_vm._v("\n                Heading 1\n              ")])])], 1), _vm._v(" "), _c("b-tr", [_c("b-td", [_c("h2", {
    staticClass: "font-weight-normal"
  }, [_vm._v("\n                Heading 2\n              ")])]), _vm._v(" "), _c("b-td", {
    staticClass: "text-right"
  }, [_c("h2", {
    staticClass: "font-weight-bolder"
  }, [_vm._v("\n                Heading 2\n              ")])])], 1), _vm._v(" "), _c("b-tr", [_c("b-td", [_c("h3", {
    staticClass: "font-weight-normal"
  }, [_vm._v("\n                Heading 3\n              ")])]), _vm._v(" "), _c("b-td", {
    staticClass: "text-right"
  }, [_c("h3", {
    staticClass: "font-weight-bolder"
  }, [_vm._v("\n                Heading 3\n              ")])])], 1), _vm._v(" "), _c("b-tr", [_c("b-td", [_c("h4", {
    staticClass: "font-weight-normal"
  }, [_vm._v("\n                Heading 4\n              ")])]), _vm._v(" "), _c("b-td", {
    staticClass: "text-right"
  }, [_c("h4", {
    staticClass: "font-weight-bolder"
  }, [_vm._v("\n                Heading 4\n              ")])])], 1), _vm._v(" "), _c("b-tr", [_c("b-td", [_c("h5", {
    staticClass: "font-weight-normal"
  }, [_vm._v("\n                Heading 5\n              ")])]), _vm._v(" "), _c("b-td", {
    staticClass: "text-right"
  }, [_c("h5", {
    staticClass: "font-weight-bolder"
  }, [_vm._v("\n                Heading 5\n              ")])])], 1), _vm._v(" "), _c("b-tr", [_c("b-td", [_c("h6", {
    staticClass: "font-weight-normal"
  }, [_vm._v("\n                Heading 6\n              ")])]), _vm._v(" "), _c("b-td", {
    staticClass: "text-right"
  }, [_c("h6", {
    staticClass: "font-weight-bolder"
  }, [_vm._v("\n                Heading 6\n              ")])])], 1)], 1)], 1)], 1)], 1), _vm._v(" "), _c("b-col", {
    attrs: {
      md: "6"
    }
  }, [_c("b-card", {
    attrs: {
      "no-body": ""
    }
  }, [_c("b-card-header", [_c("b-card-title", [_vm._v("Customizing headings "), _c("small", {
    staticClass: "text-muted"
  }, [_vm._v("Default")])])], 1), _vm._v(" "), _c("b-card-body", {
    staticClass: "pb-1"
  }, [_c("b-card-text", [_vm._v("Use the included utility classes to recreate the small secondary heading text.")])], 1), _vm._v(" "), _c("b-table-simple", {
    attrs: {
      borderless: ""
    }
  }, [_c("b-tbody", [_c("b-tr", [_c("b-td", [_c("h1", [_vm._v("Display heading "), _c("small", {
    staticClass: "text-muted"
  }, [_vm._v("Secondary text")])])])], 1), _vm._v(" "), _c("b-tr", [_c("b-td", [_c("h2", [_vm._v("Display heading "), _c("small", {
    staticClass: "text-muted"
  }, [_vm._v("Secondary text")])])])], 1), _vm._v(" "), _c("b-tr", [_c("b-td", [_c("h3", [_vm._v("Display heading "), _c("small", {
    staticClass: "text-muted"
  }, [_vm._v("Secondary text")])])])], 1), _vm._v(" "), _c("b-tr", [_c("b-td", [_c("h4", [_vm._v("Display heading "), _c("small", {
    staticClass: "text-muted"
  }, [_vm._v("Secondary text")])])])], 1), _vm._v(" "), _c("b-tr", [_c("b-td", [_c("h5", [_vm._v("Display heading "), _c("small", {
    staticClass: "text-muted"
  }, [_vm._v("Secondary text")])])])], 1), _vm._v(" "), _c("b-tr", [_c("b-td", [_c("h6", [_vm._v("Display heading "), _c("small", {
    staticClass: "text-muted"
  }, [_vm._v("Secondary text")])])])], 1)], 1)], 1)], 1)], 1), _vm._v(" "), _c("b-col", {
    attrs: {
      md: "6"
    }
  }, [_c("b-card", {
    attrs: {
      "no-body": ""
    }
  }, [_c("b-card-header", [_c("b-card-title", [_vm._v("Heading colors")])], 1), _vm._v(" "), _c("b-card-body", {
    staticClass: "pb-1"
  }, [_c("b-card-text", [_vm._v("\n          Heading elements are also changed with different color options. Use "), _c("code", [_vm._v(".text-{colorName}")]), _vm._v(" class with\n          heading elements.\n        ")])], 1), _vm._v(" "), _c("b-table-simple", {
    attrs: {
      borderless: ""
    }
  }, [_c("b-tbody", [_c("b-tr", [_c("b-td", [_c("h1", {
    staticClass: "text-primary"
  }, [_vm._v("\n                Display heading\n              ")])])], 1), _vm._v(" "), _c("b-tr", [_c("b-td", [_c("h2", {
    staticClass: "text-success"
  }, [_vm._v("\n                Display heading\n              ")])])], 1), _vm._v(" "), _c("b-tr", [_c("b-td", [_c("h3", {
    staticClass: "text-danger"
  }, [_vm._v("\n                Display heading\n              ")])])], 1), _vm._v(" "), _c("b-tr", [_c("b-td", [_c("h4", {
    staticClass: "text-warning"
  }, [_vm._v("\n                Display heading\n              ")])])], 1), _vm._v(" "), _c("b-tr", [_c("b-td", [_c("h5", {
    staticClass: "text-info"
  }, [_vm._v("\n                Display heading\n              ")])])], 1), _vm._v(" "), _c("b-tr", [_c("b-td", [_c("h6", [_vm._v("Display heading")])])], 1)], 1)], 1)], 1)], 1)], 1);
};

var staticRenderFns = [];
render._withStripped = true;


/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/ui/typography/TypographyDescription.vue?vue&type=template&id=760dbd64&":
/*!*******************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/ui/typography/TypographyDescription.vue?vue&type=template&id=760dbd64& ***!
  \*******************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function render() {
  var _vm = this,
      _c = _vm._self._c;

  return _c("section", {
    attrs: {
      id: "description-list-alignment"
    }
  }, [_vm._m(0), _vm._v(" "), _c("b-row", {
    staticClass: "match-height"
  }, [_c("b-col", {
    attrs: {
      md: "8"
    }
  }, [_c("b-card", {
    attrs: {
      "no-body": ""
    }
  }, [_c("b-card-header", [_c("b-card-title", [_vm._v("\n            Description lists "), _c("small", {
    staticClass: "text-muted"
  }, [_vm._v("Horizontal")])])], 1), _vm._v(" "), _c("b-card-body", [_c("dl", {
    staticClass: "row"
  }, [_c("dt", {
    staticClass: "col-sm-3"
  }, [_vm._v("\n              Description lists\n            ")]), _vm._v(" "), _c("dd", {
    staticClass: "col-sm-9"
  }, [_vm._v("\n              A description list is perfect for defining terms.\n            ")])]), _vm._v(" "), _c("dl", {
    staticClass: "row"
  }, [_c("dt", {
    staticClass: "col-sm-3"
  }, [_vm._v("\n              Euismod\n            ")]), _vm._v(" "), _c("dd", {
    staticClass: "col-sm-9"
  }, [_vm._v("\n              Vestibulum id ligula porta felis euismod semper eget lacinia odio sem nec elit.\n            ")])]), _vm._v(" "), _c("dl", {
    staticClass: "row"
  }, [_c("dt"), _vm._v(" "), _c("dd", {
    staticClass: "col-sm-9 ml-auto"
  }, [_vm._v("\n              Donec id elit non mi porta gravida at eget metus.\n            ")])]), _vm._v(" "), _c("dl", {
    staticClass: "row"
  }, [_c("dt", {
    staticClass: "col-sm-3"
  }, [_vm._v("\n              Malesuada porta\n            ")]), _vm._v(" "), _c("dd", {
    staticClass: "col-sm-9"
  }, [_vm._v("\n              Etiam porta sem malesuada magna mollis euismod.\n            ")])]), _vm._v(" "), _c("dl", {
    staticClass: "row"
  }, [_c("dt", {
    staticClass: "col-sm-3 text-truncate"
  }, [_vm._v("\n              Truncated term is truncated\n            ")]), _vm._v(" "), _c("dd", {
    staticClass: "col-sm-9"
  }, [_vm._v("\n              Fusce dapibus, tellus ac cursus commodo, tortor mauris condimentum nibh, ut fermentum massa justo sit amet\n              risus.\n            ")])]), _vm._v(" "), _c("dl", {
    staticClass: "row"
  }, [_c("dt", {
    staticClass: "col-sm-3"
  }, [_vm._v("\n              Nesting\n            ")]), _vm._v(" "), _c("dd", {
    staticClass: "col-sm-9"
  }, [_c("dl", {
    staticClass: "row"
  }, [_c("dt", {
    staticClass: "col-sm-4"
  }, [_vm._v("\n                  Nested definition list\n                ")]), _vm._v(" "), _c("dd", {
    staticClass: "col-sm-8"
  }, [_vm._v("\n                  Aenean posuere, tortor sed cursus feugiat, nunc augue blandit nunc.\n                ")])])])])])], 1)], 1), _vm._v(" "), _c("b-col", {
    attrs: {
      md: "4"
    }
  }, [_c("b-card", [_c("b-card-title", [_vm._v("Description lists "), _c("small", {
    staticClass: "text-muted"
  }, [_vm._v("Vertical")])]), _vm._v(" "), _c("dl", [_c("dt", [_vm._v("Description lists")]), _vm._v(" "), _c("dd", [_vm._v("A description list is perfect for defining terms.")]), _vm._v(" "), _c("dt", [_vm._v("Euismod")]), _vm._v(" "), _c("dd", [_vm._v("Vestibulum id ligula porta felis euismod semper eget lacinia odio.")]), _vm._v(" "), _c("dd", [_vm._v("Donec id elit non mi porta gravida at eget metus.")]), _vm._v(" "), _c("dt", [_vm._v("Malesuada porta")]), _vm._v(" "), _c("dd", [_vm._v("Etiam porta sem malesuada magna mollis euismod.")])])], 1)], 1), _vm._v(" "), _c("b-col", {
    attrs: {
      cols: "12"
    }
  }, [_c("b-card", [_c("b-card-title", [_vm._v("Description lists "), _c("small", {
    staticClass: "text-muted"
  }, [_vm._v("Horizontal")])]), _vm._v(" "), _c("b-card-text", [_vm._v("\n          Description lists with right aligned text in "), _c("code", [_vm._v("<dt>")]), _vm._v(" tag using "), _c("code", [_vm._v(".text-right")])]), _vm._v(" "), _c("dl", {
    staticClass: "row"
  }, [_c("dt", {
    staticClass: "col-sm-3 text-right"
  }, [_vm._v("\n            Description lists\n          ")]), _vm._v(" "), _c("dd", {
    staticClass: "col-sm-9"
  }, [_vm._v("\n            A description list is perfect for defining terms.\n          ")])]), _vm._v(" "), _c("dl", {
    staticClass: "row"
  }, [_c("dt", {
    staticClass: "col-sm-3 text-right"
  }, [_vm._v("\n            Euismod\n          ")]), _vm._v(" "), _c("dd", {
    staticClass: "col-sm-9"
  }, [_vm._v("\n            Vestibulum id ligula porta felis euismod semper eget lacinia odio sem nec elit.\n          ")])]), _vm._v(" "), _c("dl", {
    staticClass: "row"
  }, [_c("dt"), _vm._v(" "), _c("dd", {
    staticClass: "col-sm-9 ml-auto"
  }, [_vm._v("\n            Donec id elit non mi porta gravida at eget metus.\n          ")])]), _vm._v(" "), _c("dl", {
    staticClass: "row"
  }, [_c("dt", {
    staticClass: "col-sm-3 text-right"
  }, [_vm._v("\n            Malesuada porta\n          ")]), _vm._v(" "), _c("dd", {
    staticClass: "col-sm-9"
  }, [_vm._v("\n            Etiam porta sem malesuada magna mollis euismod.\n          ")])]), _vm._v(" "), _c("dl", {
    staticClass: "row"
  }, [_c("dt", {
    staticClass: "col-sm-3 text-right text-truncate"
  }, [_vm._v("\n            Truncated term is truncated\n          ")]), _vm._v(" "), _c("dd", {
    staticClass: "col-sm-9"
  }, [_vm._v("\n            Fusce dapibus, tellus ac cursus commodo, tortor mauris condimentum nibh, ut fermentum massa justo sit amet\n            risus.\n          ")])]), _vm._v(" "), _c("dl", {
    staticClass: "row"
  }, [_c("dt", {
    staticClass: "col-sm-3 text-right"
  }, [_vm._v("\n            Nesting\n          ")]), _vm._v(" "), _c("dd", {
    staticClass: "col-sm-9"
  }, [_c("dl", {
    staticClass: "row"
  }, [_c("dt", {
    staticClass: "col-sm-4"
  }, [_vm._v("\n                Nested definition list\n              ")]), _vm._v(" "), _c("dd", {
    staticClass: "col-sm-8"
  }, [_vm._v("\n                Aenean posuere, tortor sed cursus feugiat, nunc augue blandit nunc.\n              ")])])])])], 1)], 1)], 1)], 1);
};

var staticRenderFns = [function () {
  var _vm = this,
      _c = _vm._self._c;

  return _c("div", {
    staticClass: "group-area mt-1"
  }, [_c("h4", [_vm._v("Description list alignment")]), _vm._v(" "), _c("p", [_vm._v("\n      Align terms and descriptions horizontally by using our grid system’s predefined classes (or semantic mixins).\n      For longer terms, you can optionally add a "), _c("code", {
    staticClass: "highlighter-rouge"
  }, [_vm._v(".text-truncate")]), _vm._v(" class to\n      truncate the text with an ellipsis.\n    ")]), _vm._v(" "), _c("hr")]);
}];
render._withStripped = true;


/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/ui/typography/TypographyDisplay.vue?vue&type=template&id=f4eb5fd8&":
/*!***************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/ui/typography/TypographyDisplay.vue?vue&type=template&id=f4eb5fd8& ***!
  \***************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function render() {
  var _vm = this,
      _c = _vm._self._c;

  return _c("b-card", {
    attrs: {
      "no-body": ""
    }
  }, [_c("b-card-body", {
    staticClass: "pb-1"
  }, [_c("b-card-title", [_vm._v("Display headings")]), _vm._v(" "), _c("b-card-text", [_vm._v("\n      Traditional heading elements are designed to work best in the meat of your page content. When you need a heading\n      to stand out, consider using a "), _c("strong", [_vm._v("display heading")]), _vm._v(" — a larger, slightly more opinionated heading\n      style.\n    ")])], 1), _vm._v(" "), _c("b-table-simple", {
    attrs: {
      borderless: ""
    }
  }, [_c("b-tbody", [_c("b-tr", [_c("b-td", [_c("h1", {
    staticClass: "display-1"
  }, [_vm._v("\n            Display 1\n          ")])])], 1), _vm._v(" "), _c("b-tr", [_c("b-td", [_c("h2", {
    staticClass: "display-2"
  }, [_vm._v("\n            Display 2\n          ")])])], 1), _vm._v(" "), _c("b-tr", [_c("b-td", [_c("h3", {
    staticClass: "display-3"
  }, [_vm._v("\n            Display 3\n          ")])])], 1), _vm._v(" "), _c("b-tr", [_c("b-td", [_c("h4", {
    staticClass: "display-4"
  }, [_vm._v("\n            Display 4\n          ")])])], 1)], 1)], 1)], 1);
};

var staticRenderFns = [];
render._withStripped = true;


/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/ui/typography/TypographyList.vue?vue&type=template&id=7030ce88&":
/*!************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/ui/typography/TypographyList.vue?vue&type=template&id=7030ce88& ***!
  \************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function render() {
  var _vm = this,
      _c = _vm._self._c;

  return _c("section", {
    attrs: {
      id: "lists"
    }
  }, [_vm._m(0), _vm._v(" "), _c("b-row", {
    staticClass: "match-height"
  }, [_c("b-col", {
    attrs: {
      md: "4"
    }
  }, [_c("b-card", {
    attrs: {
      title: "Lists Unstyled"
    }
  }, [_c("b-card-text", [_vm._v("\n          Use class "), _c("code", [_vm._v(".list-unstyled")]), _vm._v(" for Lists Unstyled. It remove the default\n          "), _c("code", {
    staticClass: "highlighter-rouge"
  }, [_vm._v("list-style")]), _vm._v(" and left margin on list items (immediate children only).\n          "), _c("strong", [_vm._v("This only applies to immediate children list items")]), _vm._v(", meaning you will need to add the class\n          for any nested lists as well.\n        ")]), _vm._v(" "), _c("ul", {
    staticClass: "list-unstyled"
  }, [_c("li", [_vm._v("Lorem ipsum dolor sit amet")]), _vm._v(" "), _c("li", [_vm._v("Consectetur adipiscing elit")]), _vm._v(" "), _c("li", [_vm._v("Integer molestie lorem at massa")]), _vm._v(" "), _c("li", [_vm._v("Facilisis in pretium nisl aliquet")]), _vm._v(" "), _c("li", [_vm._v("\n            Nulla volutpat aliquam velit\n            "), _c("ul", [_c("li", [_vm._v("Phasellus iaculis neque")]), _vm._v(" "), _c("li", [_vm._v("Purus sodales ultricies")]), _vm._v(" "), _c("li", [_vm._v("Vestibulum laoreet porttitor sem")]), _vm._v(" "), _c("li", [_vm._v("Ac tristique libero volutpat at")])])]), _vm._v(" "), _c("li", [_vm._v("Faucibus porta lacus fringilla vel")]), _vm._v(" "), _c("li", [_vm._v("Aenean sit amet erat nunc")]), _vm._v(" "), _c("li", [_vm._v("Eget porttitor lorem")])])], 1)], 1), _vm._v(" "), _c("b-col", {
    attrs: {
      md: "4"
    }
  }, [_c("b-card", [_c("b-card-title", [_vm._v("\n          Lists Unordered "), _c("small", {
    staticClass: "text-muted"
  }, [_vm._v("Default")])]), _vm._v(" "), _c("b-card-text", [_vm._v("\n          List of items in which the order does not explicitly matter. Use "), _c("code", [_vm._v(".list-style-circle")]), _vm._v(" or\n          "), _c("code", [_vm._v(".list-style-square")]), _vm._v(" class in unordered list to add circle or square bullet points.\n        ")]), _vm._v(" "), _c("ul", [_c("li", [_vm._v("Lorem ipsum dolor sit amet")]), _vm._v(" "), _c("li", [_vm._v("Consectetur adipiscing elit")]), _vm._v(" "), _c("li", [_vm._v("Integer molestie lorem at massa")]), _vm._v(" "), _c("li", [_vm._v("Facilisis in pretium nisl aliquet")]), _vm._v(" "), _c("li", [_vm._v("\n            Nulla volutpat aliquam velit\n            "), _c("ul", [_c("li", [_vm._v("Phasellus iaculis neque")]), _vm._v(" "), _c("li", [_vm._v("Purus sodales ultricies")]), _vm._v(" "), _c("li", [_vm._v("Vestibulum laoreet porttitor sem")]), _vm._v(" "), _c("li", [_vm._v("Ac tristique libero volutpat at")])])]), _vm._v(" "), _c("li", [_vm._v("Faucibus porta lacus fringilla vel")]), _vm._v(" "), _c("li", [_vm._v("Aenean sit amet erat nunc")]), _vm._v(" "), _c("li", [_vm._v("Eget porttitor lorem")])])], 1)], 1), _vm._v(" "), _c("b-col", {
    attrs: {
      md: "4"
    }
  }, [_c("b-card", [_c("b-card-title", [_vm._v("Lists Ordered "), _c("small", {
    staticClass: "text-muted"
  }, [_vm._v("Default")])]), _vm._v(" "), _c("b-card-text", [_vm._v("\n          List of items in which the order does explicitly matter. Use "), _c("code", [_vm._v('<ol type="1|a|A|i|I">')]), _vm._v(", The\n          type attribute specifies the kind of marker to use in the list.\n        ")]), _vm._v(" "), _c("ol", [_c("li", [_vm._v("Lorem ipsum dolor sit amet")]), _vm._v(" "), _c("li", [_vm._v("Consectetur adipiscing elit")]), _vm._v(" "), _c("li", [_vm._v("Integer molestie lorem at massa")]), _vm._v(" "), _c("li", [_vm._v("Facilisis in pretium nisl aliquet")]), _vm._v(" "), _c("li", [_vm._v("\n            Nulla volutpat aliquam velit\n            "), _c("ol", [_c("li", [_vm._v("Phasellus iaculis neque")]), _vm._v(" "), _c("li", [_vm._v("Purus sodales ultricies")]), _vm._v(" "), _c("li", [_vm._v("Vestibulum laoreet porttitor sem")]), _vm._v(" "), _c("li", [_vm._v("Ac tristique libero volutpat at")])])]), _vm._v(" "), _c("li", [_vm._v("Faucibus porta lacus fringilla vel")]), _vm._v(" "), _c("li", [_vm._v("Aenean sit amet erat nunc")]), _vm._v(" "), _c("li", [_vm._v("Eget porttitor lorem")])])], 1)], 1), _vm._v(" "), _c("b-col", {
    attrs: {
      md: "6"
    }
  }, [_c("b-card", {
    attrs: {
      title: "Lists icons"
    }
  }, [_c("b-card-text", [_vm._v("\n          list of terms with icons, use "), _c("code", [_vm._v(".list-style-icons")]), _vm._v(" class. You can use any icon from Vuexy Admin\n          icon types.\n        ")]), _vm._v(" "), _c("ul", {
    staticClass: "list-style-icons"
  }, [_c("li", [_c("feather-icon", {
    attrs: {
      icon: "ArrowRightIcon"
    }
  }), _vm._v("Facilisis in pretium nisl aliquet")], 1), _vm._v(" "), _c("li", [_c("feather-icon", {
    attrs: {
      icon: "ArrowRightIcon"
    }
  }), _vm._v("Nulla volutpat aliquam velit\n            "), _c("ul", {
    staticClass: "list-style-icons"
  }, [_c("li", [_c("feather-icon", {
    attrs: {
      icon: "ChevronRightIcon"
    }
  }), _vm._v("Phasellus iaculis neque")], 1), _vm._v(" "), _c("li", [_c("feather-icon", {
    attrs: {
      icon: "ChevronRightIcon"
    }
  }), _vm._v("Ac tristique libero volutpat at")], 1)])], 1), _vm._v(" "), _c("li", [_c("feather-icon", {
    attrs: {
      icon: "ArrowRightIcon"
    }
  }), _vm._v("Faucibus porta lacus fringilla vel")], 1), _vm._v(" "), _c("li", [_c("feather-icon", {
    attrs: {
      icon: "ArrowRightIcon"
    }
  }), _vm._v("Aenean sit amet erat nunc")], 1)])], 1)], 1), _vm._v(" "), _c("b-col", {
    attrs: {
      md: "6"
    }
  }, [_c("b-card", [_c("b-card-title", [_vm._v("Inline Lists "), _c("small", {
    staticClass: "text-muted"
  }, [_vm._v("Default")])]), _vm._v(" "), _c("b-card-text", [_vm._v("\n          Remove a list’s bullets and apply some light "), _c("code", [_vm._v("margin")]), _vm._v(" with a combination of two classes,\n          "), _c("code", [_vm._v(".list-inline")]), _vm._v(" and "), _c("code", [_vm._v(".list-inline-item")]), _vm._v(".\n        ")]), _vm._v(" "), _c("b-card-text", [_vm._v("\n          Use inline numbers, alphabet, icons etc... for ordered Inline List.\n        ")]), _vm._v(" "), _c("ul", {
    staticClass: "list-inline"
  }, [_c("li", {
    staticClass: "list-inline-item"
  }, [_vm._v("\n            Chocolate\n          ")]), _vm._v(" "), _c("li", {
    staticClass: "list-inline-item"
  }, [_vm._v("\n            Cake\n          ")]), _vm._v(" "), _c("li", {
    staticClass: "list-inline-item"
  }, [_vm._v("\n            Ice-Cream\n          ")])]), _vm._v(" "), _c("ul", {
    staticClass: "list-inline"
  }, [_c("li", {
    staticClass: "list-inline-item"
  }, [_vm._v("\n            1. Chocolate\n          ")]), _vm._v(" "), _c("li", {
    staticClass: "list-inline-item"
  }, [_vm._v("\n            2. Cake\n          ")]), _vm._v(" "), _c("li", {
    staticClass: "list-inline-item"
  }, [_vm._v("\n            3. Ice-Cream\n          ")])]), _vm._v(" "), _c("ul", {
    staticClass: "list-inline"
  }, [_c("li", {
    staticClass: "list-inline-item"
  }, [_c("feather-icon", {
    attrs: {
      icon: "DollarSignIcon"
    }
  }), _vm._v(" "), _c("span", [_vm._v("250")])], 1), _vm._v(" "), _c("li", {
    staticClass: "list-inline-item"
  }, [_c("feather-icon", {
    attrs: {
      icon: "DollarSignIcon"
    }
  }), _vm._v(" "), _c("span", [_vm._v("110")])], 1), _vm._v(" "), _c("li", {
    staticClass: "list-inline-item"
  }, [_c("feather-icon", {
    attrs: {
      icon: "DollarSignIcon"
    }
  }), _vm._v(" "), _c("span", [_vm._v("890")])], 1)])], 1)], 1)], 1)], 1);
};

var staticRenderFns = [function () {
  var _vm = this,
      _c = _vm._self._c;

  return _c("div", {
    staticClass: "group-area mt-1"
  }, [_c("h4", [_vm._v("Lists")]), _vm._v(" "), _c("p", [_vm._v("\n      All lists - "), _c("code", [_vm._v("<ul>")]), _vm._v(", "), _c("code", [_vm._v("<ol>")]), _vm._v(", and "), _c("code", [_vm._v("<dl>")]), _vm._v(" - have their\n      margin-top removed and a "), _c("code", [_vm._v("margin-bottom: 1rem")]), _vm._v(". Nested lists have no "), _c("code", [_vm._v("margin-bottom")]), _vm._v(".\n    ")]), _vm._v(" "), _c("hr")]);
}];
render._withStripped = true;


/***/ }),

/***/ "./resources/js/src/views/ui/typography/Typography.vue":
/*!*************************************************************!*\
  !*** ./resources/js/src/views/ui/typography/Typography.vue ***!
  \*************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _Typography_vue_vue_type_template_id_ff57b404___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./Typography.vue?vue&type=template&id=ff57b404& */ "./resources/js/src/views/ui/typography/Typography.vue?vue&type=template&id=ff57b404&");
/* harmony import */ var _Typography_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./Typography.vue?vue&type=script&lang=js& */ "./resources/js/src/views/ui/typography/Typography.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _Typography_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _Typography_vue_vue_type_template_id_ff57b404___WEBPACK_IMPORTED_MODULE_0__["render"],
  _Typography_vue_vue_type_template_id_ff57b404___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/src/views/ui/typography/Typography.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./resources/js/src/views/ui/typography/Typography.vue?vue&type=script&lang=js&":
/*!**************************************************************************************!*\
  !*** ./resources/js/src/views/ui/typography/Typography.vue?vue&type=script&lang=js& ***!
  \**************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Typography_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../node_modules/babel-loader/lib??ref--4-0!../../../../../../node_modules/vue-loader/lib??vue-loader-options!./Typography.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/ui/typography/Typography.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Typography_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/src/views/ui/typography/Typography.vue?vue&type=template&id=ff57b404&":
/*!********************************************************************************************!*\
  !*** ./resources/js/src/views/ui/typography/Typography.vue?vue&type=template&id=ff57b404& ***!
  \********************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_vue_loader_lib_index_js_vue_loader_options_Typography_vue_vue_type_template_id_ff57b404___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../node_modules/babel-loader/lib??ref--4-0!../../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!../../../../../../node_modules/vue-loader/lib??vue-loader-options!./Typography.vue?vue&type=template&id=ff57b404& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/ui/typography/Typography.vue?vue&type=template&id=ff57b404&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_vue_loader_lib_index_js_vue_loader_options_Typography_vue_vue_type_template_id_ff57b404___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_vue_loader_lib_index_js_vue_loader_options_Typography_vue_vue_type_template_id_ff57b404___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./resources/js/src/views/ui/typography/TypographyBlockquotes.vue":
/*!************************************************************************!*\
  !*** ./resources/js/src/views/ui/typography/TypographyBlockquotes.vue ***!
  \************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _TypographyBlockquotes_vue_vue_type_template_id_275c3196___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./TypographyBlockquotes.vue?vue&type=template&id=275c3196& */ "./resources/js/src/views/ui/typography/TypographyBlockquotes.vue?vue&type=template&id=275c3196&");
/* harmony import */ var _TypographyBlockquotes_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./TypographyBlockquotes.vue?vue&type=script&lang=js& */ "./resources/js/src/views/ui/typography/TypographyBlockquotes.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _TypographyBlockquotes_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _TypographyBlockquotes_vue_vue_type_template_id_275c3196___WEBPACK_IMPORTED_MODULE_0__["render"],
  _TypographyBlockquotes_vue_vue_type_template_id_275c3196___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/src/views/ui/typography/TypographyBlockquotes.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./resources/js/src/views/ui/typography/TypographyBlockquotes.vue?vue&type=script&lang=js&":
/*!*************************************************************************************************!*\
  !*** ./resources/js/src/views/ui/typography/TypographyBlockquotes.vue?vue&type=script&lang=js& ***!
  \*************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_TypographyBlockquotes_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../node_modules/babel-loader/lib??ref--4-0!../../../../../../node_modules/vue-loader/lib??vue-loader-options!./TypographyBlockquotes.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/ui/typography/TypographyBlockquotes.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_TypographyBlockquotes_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/src/views/ui/typography/TypographyBlockquotes.vue?vue&type=template&id=275c3196&":
/*!*******************************************************************************************************!*\
  !*** ./resources/js/src/views/ui/typography/TypographyBlockquotes.vue?vue&type=template&id=275c3196& ***!
  \*******************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_vue_loader_lib_index_js_vue_loader_options_TypographyBlockquotes_vue_vue_type_template_id_275c3196___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../node_modules/babel-loader/lib??ref--4-0!../../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!../../../../../../node_modules/vue-loader/lib??vue-loader-options!./TypographyBlockquotes.vue?vue&type=template&id=275c3196& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/ui/typography/TypographyBlockquotes.vue?vue&type=template&id=275c3196&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_vue_loader_lib_index_js_vue_loader_options_TypographyBlockquotes_vue_vue_type_template_id_275c3196___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_vue_loader_lib_index_js_vue_loader_options_TypographyBlockquotes_vue_vue_type_template_id_275c3196___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./resources/js/src/views/ui/typography/TypographyDefault.vue":
/*!********************************************************************!*\
  !*** ./resources/js/src/views/ui/typography/TypographyDefault.vue ***!
  \********************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _TypographyDefault_vue_vue_type_template_id_05503613___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./TypographyDefault.vue?vue&type=template&id=05503613& */ "./resources/js/src/views/ui/typography/TypographyDefault.vue?vue&type=template&id=05503613&");
/* harmony import */ var _TypographyDefault_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./TypographyDefault.vue?vue&type=script&lang=js& */ "./resources/js/src/views/ui/typography/TypographyDefault.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _TypographyDefault_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _TypographyDefault_vue_vue_type_template_id_05503613___WEBPACK_IMPORTED_MODULE_0__["render"],
  _TypographyDefault_vue_vue_type_template_id_05503613___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/src/views/ui/typography/TypographyDefault.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./resources/js/src/views/ui/typography/TypographyDefault.vue?vue&type=script&lang=js&":
/*!*********************************************************************************************!*\
  !*** ./resources/js/src/views/ui/typography/TypographyDefault.vue?vue&type=script&lang=js& ***!
  \*********************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_TypographyDefault_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../node_modules/babel-loader/lib??ref--4-0!../../../../../../node_modules/vue-loader/lib??vue-loader-options!./TypographyDefault.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/ui/typography/TypographyDefault.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_TypographyDefault_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/src/views/ui/typography/TypographyDefault.vue?vue&type=template&id=05503613&":
/*!***************************************************************************************************!*\
  !*** ./resources/js/src/views/ui/typography/TypographyDefault.vue?vue&type=template&id=05503613& ***!
  \***************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_vue_loader_lib_index_js_vue_loader_options_TypographyDefault_vue_vue_type_template_id_05503613___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../node_modules/babel-loader/lib??ref--4-0!../../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!../../../../../../node_modules/vue-loader/lib??vue-loader-options!./TypographyDefault.vue?vue&type=template&id=05503613& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/ui/typography/TypographyDefault.vue?vue&type=template&id=05503613&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_vue_loader_lib_index_js_vue_loader_options_TypographyDefault_vue_vue_type_template_id_05503613___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_vue_loader_lib_index_js_vue_loader_options_TypographyDefault_vue_vue_type_template_id_05503613___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./resources/js/src/views/ui/typography/TypographyDescription.vue":
/*!************************************************************************!*\
  !*** ./resources/js/src/views/ui/typography/TypographyDescription.vue ***!
  \************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _TypographyDescription_vue_vue_type_template_id_760dbd64___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./TypographyDescription.vue?vue&type=template&id=760dbd64& */ "./resources/js/src/views/ui/typography/TypographyDescription.vue?vue&type=template&id=760dbd64&");
/* harmony import */ var _TypographyDescription_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./TypographyDescription.vue?vue&type=script&lang=js& */ "./resources/js/src/views/ui/typography/TypographyDescription.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _TypographyDescription_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _TypographyDescription_vue_vue_type_template_id_760dbd64___WEBPACK_IMPORTED_MODULE_0__["render"],
  _TypographyDescription_vue_vue_type_template_id_760dbd64___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/src/views/ui/typography/TypographyDescription.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./resources/js/src/views/ui/typography/TypographyDescription.vue?vue&type=script&lang=js&":
/*!*************************************************************************************************!*\
  !*** ./resources/js/src/views/ui/typography/TypographyDescription.vue?vue&type=script&lang=js& ***!
  \*************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_TypographyDescription_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../node_modules/babel-loader/lib??ref--4-0!../../../../../../node_modules/vue-loader/lib??vue-loader-options!./TypographyDescription.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/ui/typography/TypographyDescription.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_TypographyDescription_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/src/views/ui/typography/TypographyDescription.vue?vue&type=template&id=760dbd64&":
/*!*******************************************************************************************************!*\
  !*** ./resources/js/src/views/ui/typography/TypographyDescription.vue?vue&type=template&id=760dbd64& ***!
  \*******************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_vue_loader_lib_index_js_vue_loader_options_TypographyDescription_vue_vue_type_template_id_760dbd64___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../node_modules/babel-loader/lib??ref--4-0!../../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!../../../../../../node_modules/vue-loader/lib??vue-loader-options!./TypographyDescription.vue?vue&type=template&id=760dbd64& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/ui/typography/TypographyDescription.vue?vue&type=template&id=760dbd64&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_vue_loader_lib_index_js_vue_loader_options_TypographyDescription_vue_vue_type_template_id_760dbd64___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_vue_loader_lib_index_js_vue_loader_options_TypographyDescription_vue_vue_type_template_id_760dbd64___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./resources/js/src/views/ui/typography/TypographyDisplay.vue":
/*!********************************************************************!*\
  !*** ./resources/js/src/views/ui/typography/TypographyDisplay.vue ***!
  \********************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _TypographyDisplay_vue_vue_type_template_id_f4eb5fd8___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./TypographyDisplay.vue?vue&type=template&id=f4eb5fd8& */ "./resources/js/src/views/ui/typography/TypographyDisplay.vue?vue&type=template&id=f4eb5fd8&");
/* harmony import */ var _TypographyDisplay_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./TypographyDisplay.vue?vue&type=script&lang=js& */ "./resources/js/src/views/ui/typography/TypographyDisplay.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _TypographyDisplay_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _TypographyDisplay_vue_vue_type_template_id_f4eb5fd8___WEBPACK_IMPORTED_MODULE_0__["render"],
  _TypographyDisplay_vue_vue_type_template_id_f4eb5fd8___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/src/views/ui/typography/TypographyDisplay.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./resources/js/src/views/ui/typography/TypographyDisplay.vue?vue&type=script&lang=js&":
/*!*********************************************************************************************!*\
  !*** ./resources/js/src/views/ui/typography/TypographyDisplay.vue?vue&type=script&lang=js& ***!
  \*********************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_TypographyDisplay_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../node_modules/babel-loader/lib??ref--4-0!../../../../../../node_modules/vue-loader/lib??vue-loader-options!./TypographyDisplay.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/ui/typography/TypographyDisplay.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_TypographyDisplay_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/src/views/ui/typography/TypographyDisplay.vue?vue&type=template&id=f4eb5fd8&":
/*!***************************************************************************************************!*\
  !*** ./resources/js/src/views/ui/typography/TypographyDisplay.vue?vue&type=template&id=f4eb5fd8& ***!
  \***************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_vue_loader_lib_index_js_vue_loader_options_TypographyDisplay_vue_vue_type_template_id_f4eb5fd8___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../node_modules/babel-loader/lib??ref--4-0!../../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!../../../../../../node_modules/vue-loader/lib??vue-loader-options!./TypographyDisplay.vue?vue&type=template&id=f4eb5fd8& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/ui/typography/TypographyDisplay.vue?vue&type=template&id=f4eb5fd8&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_vue_loader_lib_index_js_vue_loader_options_TypographyDisplay_vue_vue_type_template_id_f4eb5fd8___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_vue_loader_lib_index_js_vue_loader_options_TypographyDisplay_vue_vue_type_template_id_f4eb5fd8___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./resources/js/src/views/ui/typography/TypographyList.vue":
/*!*****************************************************************!*\
  !*** ./resources/js/src/views/ui/typography/TypographyList.vue ***!
  \*****************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _TypographyList_vue_vue_type_template_id_7030ce88___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./TypographyList.vue?vue&type=template&id=7030ce88& */ "./resources/js/src/views/ui/typography/TypographyList.vue?vue&type=template&id=7030ce88&");
/* harmony import */ var _TypographyList_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./TypographyList.vue?vue&type=script&lang=js& */ "./resources/js/src/views/ui/typography/TypographyList.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _TypographyList_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _TypographyList_vue_vue_type_template_id_7030ce88___WEBPACK_IMPORTED_MODULE_0__["render"],
  _TypographyList_vue_vue_type_template_id_7030ce88___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/src/views/ui/typography/TypographyList.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./resources/js/src/views/ui/typography/TypographyList.vue?vue&type=script&lang=js&":
/*!******************************************************************************************!*\
  !*** ./resources/js/src/views/ui/typography/TypographyList.vue?vue&type=script&lang=js& ***!
  \******************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_TypographyList_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../node_modules/babel-loader/lib??ref--4-0!../../../../../../node_modules/vue-loader/lib??vue-loader-options!./TypographyList.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/ui/typography/TypographyList.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_TypographyList_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/src/views/ui/typography/TypographyList.vue?vue&type=template&id=7030ce88&":
/*!************************************************************************************************!*\
  !*** ./resources/js/src/views/ui/typography/TypographyList.vue?vue&type=template&id=7030ce88& ***!
  \************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_vue_loader_lib_index_js_vue_loader_options_TypographyList_vue_vue_type_template_id_7030ce88___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../node_modules/babel-loader/lib??ref--4-0!../../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??ref--6!../../../../../../node_modules/vue-loader/lib??vue-loader-options!./TypographyList.vue?vue&type=template&id=7030ce88& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/ui/typography/TypographyList.vue?vue&type=template&id=7030ce88&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_vue_loader_lib_index_js_vue_loader_options_TypographyList_vue_vue_type_template_id_7030ce88___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_loaders_templateLoader_js_ref_6_node_modules_vue_loader_lib_index_js_vue_loader_options_TypographyList_vue_vue_type_template_id_7030ce88___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ })

}]);